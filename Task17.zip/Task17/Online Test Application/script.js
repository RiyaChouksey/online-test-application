const questions = [
    {
        section: "HTML & CSS",
        questions: [
            { question: "1. Question 1", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "a" },
            { question: "2. Question 2", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "b" },
            { question: "3. Question 3", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "c" },
            { question: "4. Question 4", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "d" },
            { question: "5. Question 5", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "a" }
        ]
    },
    {
        section: "JavaScript",
        questions: [
            { question: "1. Question 1", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "b" },
            { question: "2. Question 2", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "c" },
            { question: "3. Question 3", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "d" },
            { question: "4. Question 4", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "a" },
            { question: "5. Question 5", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "b" }
        ]
    },
    {
        section: "jQuery",
        questions: [
            { question: "1. Question 1", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "c" },
            { question: "2. Question 2", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "d" },
            { question: "3. Question 3", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "a" },
            { question: "4. Question 4", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "b" },
            { question: "5. Question 5", options: ["a. Answer 1", "b. Answer 2", "c. Answer 3", "d. Answer 4"], answer: "c" }
        ]
    }
];

window.onload = function() {
    const quizContainer = document.getElementById('quiz-container');
    let quizContent = '';

    questions.forEach((section, sectionIndex) => {
        quizContent += `<div class="section">
                            <h2>${section.section}</h2>
                            <form id="form-section-${sectionIndex}">`;

        section.questions.forEach((q, qIndex) => {
            quizContent += `<div class="question">
                                <p>${q.question}</p>`;
            q.options.forEach((option, oIndex) => {
                quizContent += `<input type="radio" name="q${sectionIndex * 5 + qIndex}" value="${option.charAt(0)}"> ${option}<br>`;
            });
            quizContent += `</div>`;
        });

        quizContent += `</form></div>`;
    });

    quizContainer.innerHTML = quizContent;
}

function submitTest() {
    let score = 0;
    let totalQuestions = 0;

    questions.forEach((section, sectionIndex) => {
        const form = document.getElementById(`form-section-${sectionIndex}`);
        section.questions.forEach((q, qIndex) => {
            const name = `q${sectionIndex * 5 + qIndex}`;
            const selectedOption = form.querySelector(`input[name="${name}"]:checked`);
            if (selectedOption && selectedOption.value === q.answer) {
                score++;
            }
            totalQuestions++;
        });
    });

    const resultDiv = document.getElementById('result');
    resultDiv.textContent = `You scored ${score} out of ${totalQuestions}`;
}
